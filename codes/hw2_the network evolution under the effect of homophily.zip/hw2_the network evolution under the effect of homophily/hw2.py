# hw2 simulate the network evolution under the effect of homophily https://karenlyu21.github.io/hw-ss-computing/2.html
import numpy as np
# read data file and store the matrix in the form of a nested list
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
def arrayGen(filename, prt = ''):
    f = open(filename, 'r')
    r_list = f.readlines()
    f.close()
    array_nl = []
    for line in r_list:
        if line == '\n':
            continue
        line = line.strip('\n')
        line = line.strip()
        row_list = line.split(' ')
        for k in range(len(row_list)):
            row_list[k] = int(row_list[k])
        array_nl.append(row_list)
    n = len(array_nl[0])
    print('输入%s矩阵文件名：%s' % (prt, filename))
    array = np.array(array_nl)
    return array, n
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
def edgeAdder(A, B, an, bn, s, f, m):
## triadic closure adder
    A_alters = []
    B_alters = []
    for i in range(an):
        for j in range(i+1, an):
            if A[i][j] == 1:
                continue
            if np.dot(A[i], A[j]) >= s:
                A_alters.append([i, j])
                print('三元闭包（人，人）：\t%i %i' % (i, j))
## social focal closure adder
    for i in range(an):
        for j in range(i+1, an):
            if A[i][j] == 1:
                continue
            if np.dot(B[i], B[j]) >= f:
                A_alters.append([i,j])
                print('社团闭包（人，人）：\t%i %i' % (i, j))
## membership closure adder
    for i in range(an):
        for c in range(bn):
            if B[i][c] == 1:
                continue
            if np.dot(A[i], B[:,c]) >= m:
                B_alters.append([i, c])
                print('会员闭包（人，事）：\t%i %i' % (i, c))
    for item in A_alters:
        A[item[0]][item[1]] = 1
        A[item[1]][item[0]] = 1
    for item in B_alters:
        B[item[0]][item[1]] = 1
    return A, B, len(A_alters) + len(B_alters)
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

fname_a = './input/a.txt'
fname_b = './input/b.txt'
A, An = arrayGen(fname_a, '邻接')
B, Bn = arrayGen(fname_b, '归属')
try:
    s = int(input('请输入三元闭包的临界值（请输入整数）：')) # triadic closure
    f = int(input('请输入社团闭包的临界值（请输入整数）：')) # social focal closure
    m = int(input('请输入会员闭包的临界值（请输入整数）：')) # membership closre
except:
    print('输入错误，使用默认值s = 3, f = 2, m = 2。')
    s = 3
    f = 2
    m = 2

round = 1
print('第 1 轮：')
while True:
    A_new, B_new, alters = edgeAdder(A, B, An, Bn, s, f, m)
    if alters == 0:
        break
    else:
        A = A_new
        B = B_new
        round += 1
        print('第 %i 轮：' % round)
print('演化结束！')
print(A)
print(B)
