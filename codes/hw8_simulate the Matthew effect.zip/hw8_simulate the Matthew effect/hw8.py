# hw8 simulate the Matthew effect https://karenlyu21.github.io/hw-ss-computing/8.html
print('Initiating...')
import random
import matplotlib.pyplot as plt
import numpy as np

# 被选中的网页增加一个入度，对degreeDict的影响如下
def degreeDictModifier(degreeDict, choice): 
    degreeDict[choice] -= 1
    designated = choice + 1
    if designated in degreeDict.keys():
        degreeDict[designated] += 1
    else:
        degreeDict[designated] = 1
    return degreeDict

def webCreate(degreeDict, p):
    degreeKinds = list(degreeDict.keys()) # 现有网页有的度数一共有这么些种
    degreeCount = list(degreeDict.values()) # 每一元素表示，度数为某一种的网页一共有几个
    randNum = random.random()
    if randNum < p:
        randChoiceList = random.choices(degreeKinds, weights=degreeCount, k=1) 
        # 给度数加权后，选择某一网页的概率是相等的
        randChoice = randChoiceList[0]
        degreeDict = degreeDictModifier(degreeDict, randChoice)
        
    else:
        newWeights = []
        for kind, cnt in degreeDict.items():
            newWeights.append(cnt * kind)
        slantedChoiceList = random.choices(degreeKinds, weights=newWeights, k=1)
        # 采用这一新的加权法后，某一网页被选中的概率与度数成正比
        slantedChoice = slantedChoiceList[0]
        degreeDict = degreeDictModifier(degreeDict, slantedChoice)
    degreeDict[0] += 1
    return degreeDict

def webCreateSeries(n, p, outputF):
    print('* * * * * * A new round begins. n = %i, p = %.2f * * * * * *' % (n, p))
    cnt = 0
    outputF.write('n = %i p = %.2f\n' % (n, p))
    # 循环完成10000个网页的创建
    degreeDict = {0:1}
    while True:
        cnt += 1
        if cnt >= n:
            break
        if cnt % 100 == 0:
            print('%i pages have been created.' % cnt, end = '\r')
        degreeDict = webCreate(degreeDict, p)
    print()
    # 输出结果到csv
    degreeList = list(degreeDict.items())
    degreeList.sort(key = lambda x:x[0])
    ## 删除网页数为0的度数，不然csv里一行太长了不好看
    for i in range(degreeList[0][0], degreeList[-1][0] + 1):
        if degreeDict[i] == 0:
            del degreeDict[i]
    degreeKinds = degreeDict.keys() # 现有网页有的度数一共有这么些种
    degreeCount = degreeDict.values() # 每一元素表示，度数为某一种的网页一共有几个
    outputF.write('degree,')
    for degreeKind in degreeKinds:
        outputF.write('%i,' % degreeKind)
    outputF.write('\namount,')
    for degreeCNT in degreeCount:
        outputF.write('%i,' % degreeCNT)
    outputF.write('\n')
    # 为了画图，补上网页数为0的度数
    degreeList = list(degreeDict.items())
    degreeList.sort(key = lambda x:x[0])
    for i in range(degreeList[0][0], degreeList[-1][0] + 1):
        if i not in degreeDict.keys():
            degreeDict[i] = 0 # for log scale
        elif degreeDict[i] == 0:
            degreeDict[i] == 0 # for log scale
    degreeList = list(degreeDict.items())
    degreeList.sort(key = lambda x:x[0])
    degreeKinds = [degreeList[i][0] for i in range(len(degreeList))]
    degreeCount = [degreeList[i][1] for i in range(len(degreeList))]
    # 横轴纵轴数据
    xPoints = np.array(degreeKinds)
    yPoints = np.array(degreeCount)
    print('This round all done.')
    return xPoints, yPoints

# 手动输入n/p值
# # p值
# try:
#     p = input('请输入一个0～1之间的p值（创建网页时，以p的概率，随机链接网页，以1-p的概率，按照与度数成正比的概率链接网页）：')
#     p = float(p)
# except:
#     print('输出错误，采用默认p值0.5。')
#     p = 0.5
# # n值
# try:
#     p = input('请输入一个正整数n值，这是我们一共要创建的网页数：')
#     p = int(p)
# except:
#     print('输出错误，采用默认n值10000。')
#     p = 10000

outputF = open('./output/distribution.csv', 'w')
fig = plt.figure()
ax1 = plt.subplot(2,2,1)
ax3 = plt.subplot(2,2,2)
ax5 = plt.subplot(2,2,3)
# fig, ((ax1, ax3), (ax5,)) = plt.subplots(2,2)
# n = 10000, p = 0.25
x1, y1 = webCreateSeries(10000, 0.25, outputF)
# n = 10000, p = 0.75
x2, y2 = webCreateSeries(10000, 0.75, outputF)
outputF.close()

# 让x轴的元素数变成一样
# if len(x1) > len(x2):
#     x = x1
#     y_add = np.array([0 for i in range(len(x1) - len(x2))])
#     y2 = np.concatenate((y2, y_add), ax1is=None)
# else:
#     x = x2
#     y_add = np.array([0 for i in range(len(x2) - len(x1))])
#     y1 = np.concatenate((y1, y_add), ax1is=None)

# 画图
## original scale
print('Drawing the picture...')
color1 = 'tab:red'
ax1.set_title('original scale')
ax1.plot(x1,y1,color=color1)
ax1.set_xlabel('degree')
ax1.set_ylabel('amount of web pages (p = 0.25)',color=color1)
ax1.tick_params(axis='y')
ax2 = ax1.twinx() # 把两次的结果画进同一个坐标系
color2 = 'tab:blue'
ax2.plot(x2,y2,color=color2)
ax2.set_ylabel('amount of web pages (p = 0.75)',color=color2)
ax2.tick_params(axis='y')
print('finished drawing the original scale')
## log scale
ax3.set_title('log scale')
ax3.plot(x1,y1,color=color1)
ax3.set_xlabel('degree')
ax3.set_ylabel('amount of web pages (p = 0.25)',color=color1)
ax3.tick_params(axis='y')
ax3.set_xscale('log')
ax3.set_yscale('log')
ax4 = ax3.twinx() 
ax4.plot(x2,y2,color=color2)
ax4.set_ylabel('amount of web pages (p = 0.75)',color=color2)
ax4.tick_params(axis='y')
ax4.set_xscale('log')
ax4.set_yscale('log')
print('finished drawing the log scale')
# 为了图更好看（不呈锯齿状），让网页数y对（最大度数 – x）积分。积分后，每一度数x对应的新y值 = 有多少网页的入度大于这一度数
ax5.set_title('integral (log scale)')
y1_new = np.copy(y1)
for i in range(len(x1)):
    pageSum1 = np.sum(y1[i:])
    y1_new[i] = pageSum1
y2_new = np.copy(y2)
for i in range(len(x2)):
    pageSum2 = np.sum(y1[i:])
    y2_new[i] = pageSum2
ax5.plot(x1,y1_new,color=color1)
ax5.set_xlabel('degree')
ax5.set_ylabel('sum of web pages (p = 0.25)',color=color1)
ax5.tick_params(axis='y')
ax5.set_xscale('log')
ax5.set_yscale('log')
ax6 = ax5.twinx()
ax6.plot(x2,y2_new,color=color2)
ax6.set_ylabel('sum of web pages (p = 0.75)',color=color2)
ax6.tick_params(axis='y')
ax6.set_xscale('log')
ax6.set_yscale('log')
print('finished drawing the log scale for the sum of web pages')

fig.tight_layout()
# fig.set_size_inches(7, 8)
plt.show()
fig.savefig('./output/distribution.png', dpi=300)