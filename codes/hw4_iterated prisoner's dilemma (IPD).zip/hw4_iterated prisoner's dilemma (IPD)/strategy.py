# 策略集合
import random

def p1(i,me,him):
    cooperate=True
    if i>0 and him[0]=='D':cooperate=False #If the partner betrays at first, cooperation will not exist.
    elif i>3: #I will cooperate in the first 4 games as long as the partner does not betray at first.
        check,count_twenty,count_fifty,count_hundred=True,0,0,0
        for j in range(i-2):
            count=0
            for k in range(j,j+2):
                if him[k]=='D':count+=1
            if count>1:
                cooperate,check=False,False
                break #If the partner betrays two or more times in any three consecutive games, cooperation will no longer continue.
        if i>20 and check:
            for k in range(i-20,i):
                if him[k]=='D':count_twenty+=1
        if count_twenty>1:cooperate,check=False,False #If the partner betrays two or more times in the last 20 games, cooperation will not continue until 20 games later.
        if i>50 and check:
            for k in range(i-50,i):
                if him[k]=='D':count_fifty+=1
        if count_fifty>2:cooperate,check=False,False #If the partner betrays three or more times in the last 50 games, cooperation will not continue until 50 games later.
        if i>100 and check:
            for k in range(i-100,i):
                if him[k]=='D':count_hundred+=1
        if count_hundred>4:cooperate=False #If the partner betrays five or more times in the last 100 games, cooperation will not continue until 100 games later.
    if cooperate:return 'C' #If cooperation, I will cooperate.
    else:return him[i-1] #If no cooperation, I will do TFT.

def p2(i, me, him):
    if i == 0:
        return 'C'
    elif him[i-1] == 'C':
        return 'C'
    elif random.random() < 0.15:
        return 'C'
    else:
        return 'D'

def p3(i, me, him):
    if i == 0:
        return 'C'
    else:
        if him[i-1] == 'C':
            return 'C'
        else:
            return 'D'

def p4(i,me,him):
    if i==0:
        return 'C'
    else:
        test=0
        for tt in range(2,i):
            if him[tt-1]!=me[tt-2]:
                test=1 #不是正向复读机
        if test==0:
            return 'C'
        if test==1:
            for t in range(2,i):
                if him[t-1]==me[t-2]:
                    test=2 #不是负向复读机
            if test==1:
                return 'D'
            if test==2:
                for ttt in range(1,i-1):
                    if him[ttt]=='D':#不是一直合作者
                        test=3
                if test==2:
                    return 'D'
                if test==3:
                    for tttt in range(1,i-1):
                        if him[tttt]=='C': #不是一直欺骗者
                            test=4
                    if test==3:
                        return 'D'
                    if test==4:
                        p=0
                        p=random.randint(0,4)
                        if p==1:
                            return 'C'
                        else:
                            return 'D'

def p5(i,me,him):
    
    def threshold(me,him):
        if len(me) == 0:
            return 0.5
        else:
            ccnt = 0
            dcnt = 0
            if 'C' in me:
                for i in range(len(me)):
                    if me[i] == 'C':
                        if him[i] == 'C':
                            ccnt += 1
                        else:
                            dcnt += 1
                if ccnt + dcnt > 30:
                    return ccnt/(ccnt+dcnt)
        return 0.5
    
    if i == 0:
        return 'C'
    else:
        if him[i-1] == 'C' and me[i-1] == 'C':
            return 'C'
        elif him[i-1] == 'C' and me[i-1] == 'D':
            return 'D'
        elif him[i-1] == 'D' and me[i-1] == 'D':
            a = random.random()
            if a < threshold(me,him):
                return 'C'
            else:
                return 'D'
        else:
            return 'D'

def p6(i,me,him):
    if i == 0 or i == 1:
        return 'C'
    else:
        if him[i-1] == him[i - 2] == 'D':
            return 'D'
        else:
            return 'C'

def p7(i,me,him):
    if i == 0:
        return 'C'
    else:
        if him[i-1]=='C':
            return 'C'
        else:
            return 'D'

def p8(i,me,him):
    if i==0 or i==1:
        return 'C'
    else:
        return him[i-1]

def p9(i,me,him):
    if i==0:
        return 'C'
    else:
        if him[i-1]=='C':
            return 'C'
        else:
            return 'D'

def p10(i, me, him):
    
    # guess his ploy
    if i > 3:
        flag = None
        cnt1_1 = 0
        cnt1_2 = 0
        cnt2_1 = 0
        cnt2_2 = 0
        for j in range(i-1):
            if me[j-1] == 'C':
                cnt1_1 += 1
                if me[j-1] == him[j]:
                    cnt1_2 += 1
            elif him[j] == 'C':
                cnt2_1 += 1
                if j > 2 and max(set(me), key = me.count) == him[j]:
                    cnt2_2 += 1
    
        if 'D' not in him[2:]:
            flag = 'innocent'
        elif cnt1_2 / (cnt1_1 - 1) > 0.9 and cnt1_2 >= 2:
            flag = 's-retri'
        elif cnt2_1 > 0:
            if cnt2_2 / cnt2_1 > 0.9:
                flag = 'l-retri'

    # my reaction
    if i in [0,1,2,3]:
        return 'C' # elicit his ploy
    
    else:
        if flag == None:
            return 'D'
        elif flag == 'innocent':
            return 'D'
        elif flag in ['s-retri','l-retri']:
            return 'C'

def p11(i, me, him):
    if i <= 2 :
        return 'C'
        #初始三次均合作
    else:
        kindness = him.count('C') / len(him)  # 计算对方历史友善度
        if kindness > 0.5:
            #友善度较高，以牙还牙,倾向于合作
            if him[-1] == 'D':
                #前一次背叛，根据前三次友善度随机背叛
                betray_him = him[-3::].count('D')/3
                choice = random.random() + 0.1
                if choice > betray_him:
                    return 'C'
                else:
                    return 'D'
            else:
                #前一次合作，选择合作
                return 'C'
        elif kindness > 0.1:
            #友善度较低，尝试合作，不行就永不合作
            if him[-1] == 'D':
                #以牙还牙，比我更过分的就丧失信任
                betray_him = him[-3::].count('D')/3
                betray_me = me[-3::].count('D')/3
                if betray_me < betray_him:
                    #我前三次友善度更高，我不再信任
                    return 'D'
                else:
                    #我前三次友善度更低，我根据前三次友善度随机背叛
                    choice = random.random() + 0.1
                    if choice > betray_him:
                        return 'C'
                    else:
                        return 'D'
            if him[-1] == 'C':
                #如果示好得到回应，根据前两次友善度合作
                if me[-2] == 'C':
                    betray_him = him[-2::].count('D') / 3
                    choice = random.random() + 0.1
                    if choice > betray_him:
                        return 'C'
                    else:
                        return 'D'
                if me[-2] == 'D':
                    #如果对方主动合作，前一次合作就继续合作
                    return 'C'
        else:
            #友善度过低，对方可能按照占优策略无脑背叛，选择背叛，小概率合作试探
            if me[-3] == 'C' and 'D' not in him[-2::]:
                #试探合作得到极友善回应，继续合作
                return 'C'
            else:
                luck = random.random()
                if luck > 0.1:
                    if 'C' in him[-3::]:
                        #存在友善表现，1/3概率合作去试探
                        if luck > 0.7:
                            return 'C'
                        else:
                            return 'D'
                    else:
                        #十分不友善，选择背叛
                        return 'D'
                else:
                    #0.1的概率随机合作试探
                    return 'C'

def devil(i,me,him):
    if i==0:
        return 'D'
    else:
        if him[i-1]=='C':
            return 'D'
        else:
            return 'C'
