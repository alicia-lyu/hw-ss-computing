#hw4 simulate the iterated prisoner's dilemma (IPD) https://karenlyu21.github.io/hw-ss-computing/4.html
import strategy

strategies = [strategy.p1, strategy.p2, strategy.p3, strategy.p4, strategy.p5, strategy.p6,\
    strategy.p7, strategy.p8, strategy.p9, strategy.p10, strategy.p11, strategy.devil]
outputF = open('./output/output.csv', 'w') # for scores
outputF2 = open('./output/output.txt', 'w') # for analysis

def game_dual(n,i,j):
    me = []
    me_score = 0
    me_str = strategies[i-1]
    him = []
    him_score = 0
    him_str = strategies[j-1]
    for k in range(n):
        # actions
        me_react = me_str(k,me,him)
        him_react = him_str(k,him,me)
        me.append(me_react)
        him.append(him_react)
        # scores
        if me_react == 'D' and him_react == 'D':
            me_score += 1
            him_score += 1
        elif me_react == 'C' and him_react == 'D':
            me_score += 0
            him_score += 5
        elif him_react == 'C' and me_react == 'D':
            him_score += 0
            me_score += 5
        else:
            him_score += 3
            me_score += 3
    return me_score, him_score

def game(n, devil=False):

    score_dict = {}
    print('Game on... (%i rounds in all)' % n)
    if devil == False:
        end = 12
    else:
        end = 13

    scores = [0 for i in range(end)]

    for i in range(1, end):
        for j in range(i+1, end):
            me_score, him_score = game_dual(n,i,j)
            score_dict[i,j] = [me_score,him_score]
            print('%i v.s. %i: %i – %i' % (i,j,me_score,him_score))
            scores[i] += me_score
            scores[j] += him_score
    outputF.write('devil = %s and n = %i\n' % (str(devil), n))
    outputF2.write('*** devil = %s and n = %i ***\n' % (str(devil), n))

    for i in range(1,end): # total scores of each one
        outputF.write('%i,%i\n' % (i, scores[i]))
        print('%i: %i' % (i, scores[i]))
    
    
    scores_individuals = {} 
    for i in range(1,end):
        scores_individuals[i] = {} # store how many points each one get from i

    for key,value in score_dict.items():
        for i in range(1,end):
            if i in key:
                i_index = key.index(i)
                j = key[1 - i_index]
                j_score = value[1 - i_index]
                scores_individuals[i][j] = j_score
    
    best_reacted_dict = {} 
    for key, value in scores_individuals.items():
        best_reacted = [0,0] # store which one has reacted best against [key]
    # find out the best reaction strategy
        for j, j_score in value:
            if j_score > best_reacted[1]:
                best_reacted = [j, j_score]
            elif j_score == best_reacted[1]:
                best_reacted.append(j)
                best_reacted.append(j_score)
        if best_reacted[0:2] == [0,0]:
            del best_reacted[0:2]
        best_reacted_dict[key] = best_reacted
        print('* 对%i，p%s是最佳应答策略。' % (key, best_reacted[0:-1:2]))
        outputF2.write('* 对%i，p%s是最佳应答策略。\n' % (key, best_reacted[0:-1:2]))
    print()

    # find out the dominant strategy
    dominant = [1] + best_reacted_dict[1][0:-1:2]
    for i in range(2, end):
        next_range = best_reacted_dict[i][0:-1:2] + [i]
        dominant = [x for x in dominant if x in next_range]
    print('（非严格）占优策略：', end = '')
    print(dominant)
    outputF2.write('（非严格）占优策略：')
    if dominant == []:
        outputF2.write('无。\n')
    else:
        for item in dominant:
            outputF2.write('%i, ' % item)
        outputF2.write('\n')

    # find out the reciprocal best reaction strategy
    reciprocal = []
    for key, value in best_reacted_dict.items():
        for j in range(0, len(value), 2):
            if value[j] > key:
                for k in range(0, len(best_reacted_dict[value[j]]), 2):
                    if key == best_reacted_dict[value[j]][k]:
                        reciprocal.append([key,value[j]])
    print('互为最佳应答策略:', end = ' ')
    print(reciprocal)
    outputF2.write('互为最佳应答策略：')
    for item in reciprocal:
        a = item[0]
        b = item[1]
        outputF2.write('%i – %i | ' % (a,b))
    outputF2.write('\n')

    print('- ' * 20)
    outputF2.write('- ' * 20)
    outputF2.write('\n')
    return score_dict

score_dict_whole = {0:{}, 1:{}}

for n in [1,10,100,1000]:
    print('无devil, n = %i' % n)
    score_dict_whole[0][n] = game(n)
    print('有devil, n = %i' % n)
    score_dict_whole[1][n] = game(n, True)



        