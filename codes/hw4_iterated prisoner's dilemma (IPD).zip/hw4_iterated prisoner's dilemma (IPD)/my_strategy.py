def p1800012145(i, me, him):

    # guess his ploy
    if i > 3:
        flag = None
        cnt1_1 = 0
        cnt1_2 = 0
        cnt2_1 = 0
        cnt2_2 = 0
        for j in range(i-1):
            if me[j-1] == 'C':
                cnt1_1 += 1
                if me[j-1] == him[j]:
                    cnt1_2 += 1
            elif him[j] == 'C':
                cnt2_1 += 1
                if j > 2 and max(set(me), key = me.count) == him[j]:
                    cnt2_2 += 1

        if 'D' not in him[2:]:
            flag = 'innocent'
        elif cnt1_2 / (cnt1_1 - 1) > 0.9 and cnt1_2 >= 2:
            flag = 's-retri'
        elif cnt2_1 > 0:
            if cnt2_2 / cnt2_1 > 0.9:
                flag = 'l-retri'
    
    # my reaction
    if i in [0,1,2,3]:
        return 'C' # elicit his ploy

    else:
        if flag == None:
            return 'D'
        elif flag == 'innocent':
            return 'D'
        elif flag in ['s-retri','l-retri']:
            return 'C'