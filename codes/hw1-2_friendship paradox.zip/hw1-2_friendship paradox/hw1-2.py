# hw1-2 corroborate friendship paradox https://karenlyu21.github.io/hw-ss-computing/1.html

import random
import os
import matplotlib.pyplot as plt
import numpy as np
import time

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# Matrix generator according to small world phenomenon
def neighbor_generator(n, r, p, dir, rnd):
    filename = '%i.log' % rnd
    pathname = os.path.join(dir,filename)
    file = open(pathname, 'w')
    matr = np.zeros((n,n))
    # homophily
    file.write('Generating an orderly matrix with homophilous links...\n')
    edge_list = []
    for i in range(0,n):
        # if i % 1000 == 0:
        #     print('%i nodes processed...' % i, end = '\r')
        j_list = [(i + x) % n for x in range(1, int(r/2 + 1 + r % 2))]
        for j in j_list:
            matr[i][j] = 1
            matr[j][i] = 1
            if j > i:
                edge_list.append([i,j])
            else:
                edge_list.append([j,i])
    file.write('Writing the list of node pairs which do not have an edge...\n')
    empt_list = []
    for i in range(0,n):
        if i % 100 == 0:
            file.write('%i nodes processed...' % i)
        for j in range(i+1,n):
            if matr[i][j] == 0:
                empt_list.append([i,j])
    file.write('For now, number of edges in Matrix A: %i\n' % np.sum(matr))
    # if r is an odd, delete a half of the previously generated links between two individuals with neighboring marks
    if r % 2 != 0: 
        for i in range(0, n-1, 2):
            matr[i][i+1] = 0
            matr[i+1][i] = 0
            edge_list.remove([i, i + 1])
            empt_list.append([i, i + 1])
    file.write('Number of edges in Matrix A: %i\n' % np.sum(matr))
    # randomness
    file.write('Introducing randomness...\n')
    exc_edge = random.sample(edge_list, int(n * r * p / 2))
    exc_empt = random.sample(empt_list, int(n * r * p / 2))
    for item in exc_edge:
        matr[item[0]][item[1]] = 0
        matr[item[1]][item[0]] = 0
    for item in exc_empt:
        matr[item[0]][item[1]] = 1
        matr[item[1]][item[0]] = 1
    # npfilename = os.path.join(dir,'%i_matrix.txt' % rnd)
    # np.savetxt(npfilename,matr,fmt='%i')
    file.close()
    return matr
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# Friendship paradox indices & scales calculator
def paradox(matr, n): # verify friendship paradox
    fr_dict = {}
    dg_dict = {}
    # generate fr_dict to store who's whose friend
    for i in range(0, n):
        fr_dict[i] = []
        for j in range(0, n):
            if matr[i][j] == 1:
                fr_dict[i].append(j)
    # generate the degrees of individuals
    for i in range(0, n):
        dg_dict[i] = {}
        dg_dict[i]['self'] = len(fr_dict[i])
    # generate the average degrees of neighbors
    for i in range(0, n):
        dg_dict[i]['nb'] = 0
        for friend in fr_dict[i]:
            if fr_dict[i] == []:
                dg_dict[i]['nb'] = 0
            else:
                dg_dict[i]['nb'] += dg_dict[friend]['self'] / len(fr_dict[i])
    # calculate the index of friendship paradox
    pdIndex = 0
    for i in range(0, n):
        if 1.1 * dg_dict[i]['self'] < dg_dict[i]['nb']:
            pdIndex += 1
    pdScale = pdIndex / n
    return [pdScale, pdScale > 0.5]
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# Average paradox scales calculator
# use the same set of parameters to calculate paradox scales a few times and get the mean of paradox scales,
# so that the result has better representativeness
def pdE_calculator(n, r, p, loopCount = 100):
    k = 0
    pdSum = 0
    dir = './output/generator_logs/n=%i_r=%i_p=%.2f' % (n,r,p)
    if os.path.isdir(dir):
        pass
    else:
        os.makedirs(dir)
    while True:
        matr = neighbor_generator(n, r, p, dir, k)
        pdScale = paradox(matr, n)[0]
        k += 1
        pdSum += pdScale
        if k == int(loopCount):
            print('given n = %i, r = %i, p = %.2f, the paradox scale has been successfully calculated' % (n, r, p), end = '\n') 
            break
        if n >= 500 or loopCount >= 300:
            if k == 1:
                print('wait a few seconds for the computer to process...', end ='\r')
            if n >= 500 and k % int(5000 / n) == 0 and k > 10:
                print('%i out of %i rounds have been successfully runned........' % (k, loopCount), end = '\r')
            if loopCount >= 300 and k % 100 == 0 and k > 300:
                print('%i out of %i rounds have been successfully runned........' % (k, loopCount), end = '\r')
    pdE = pdSum / loopCount
    return pdE
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 
# Output function (printer & csv writer & image painter)
def pdOutput(parameter, parameterList, pdEList, f):
    ## calculate paradox scales
    print('Paradox scales of different %s values as following...' % parameter)
## output results
    f.write('%s,' % parameter)
    for i in parameterList:
        print(i, end = '\t')
        f.write(str(i) + ',')
    print()
    f.write('\nParadox Expectation,')
    for pd in pdEList:
        print('%.3f' % pd, end = '\t')
        f.write('%.3f' % pd + ',')
    print()
    f.write('\n')
    xPoints = np.array(parameterList)
    yPoints = np.array(pdEList)
    plotNumDict = {'n' : 1, 'r' : 2, 'p' : 3}
    plt.subplot(2, 2, plotNumDict[parameter])
    plt.plot(xPoints, yPoints, marker  = 'o')
    plt.xlabel('%s values' % parameter)
    plt.ylabel('average paradox scales')
# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - 


# output file ready
resultDir = './output'
if os.path.isdir(resultDir): 
    pass
else:
    os.makedirs(resultDir)
fname = './output/friendship paradox.csv'
f = open(fname, 'w')
# different n values
n_start = time.time()
print('*** Calculating paradox scales given different n values ***')
n_list = [50, 100, 150, 200, 300, 500, 600, 800, 1000] # more than 7 groups to make the tendency more explicit
n_pdList = []
for n in n_list:
    n_pdE = pdE_calculator(n, 5, 0.25)
    n_pdList.append(n_pdE)
pdOutput('n', n_list, n_pdList, f)
n_end = time.time()
n_span = n_end - n_start
n_time = '%i min %i s' % (n_span // 60, n_span % 60)
print('Paradox scales calculating of different n values cost', n_time)
print()
# different r values
print('*** Calculating paradox scales given different r values ***')
r_list = [3, 4, 5, 6, 7, 8, 9, 10]
r_pdList = []
for r in r_list:
    r_pdE = pdE_calculator(100, r, 0.25)
    r_pdList.append(r_pdE)
pdOutput('r', r_list, r_pdList, f)
r_end = time.time()
r_span = r_end - n_end
r_time = '%i min %i s' % (r_span // 60, r_span % 60)
print('Paradox scales calculating of different r values cost', r_time)
print()
# different p values
print('*** Calculating paradox scales given different p values ***')
p_list = [0.15, 0.25, 0.35, 0.45, 0.55, 0.65, 0.75, 0.85, 0.95]
p_pdList = []
for p in p_list:
    p_loop = 75 / (1 - p) 
    # the more randomness were introduced, the more loops are needed
    # so that I could get a stable average value of paradox scales
    p_pdE = pdE_calculator(100, 5, p, p_loop)
    p_pdList.append(p_pdE)
pdOutput('p', p_list, p_pdList, f)
p_end = time.time()
p_span = p_end - r_end
p_time = '%i min %i s' % (p_span // 60, p_span % 60)
print('Paradox scales calculating of different p values cost', p_time)
print()
figure = plt.gcf()
figure.tight_layout()
plt.savefig('./output/friendship paradox.png', dpi = 300)
plt.show()
    



