# -*- coding:utf-8 -*-
# Aaron Wu
"""
程序提供perfect_match函数，该函数接收一个2n个节点二部图的邻接矩阵，前n个节点可认为二部图左部，后n个节点为右部。
若存在完美匹配，函数返回真及一个完美匹配的边集合，否则返回假并给出右部节点的一个受限集关联的左部邻居节点集合。
基本思路为对左部未匹配节点作交替BFS，找增广路径，详见教材10.6或"匈牙利算法"。
"""
def perfect_match(matrix):
    node_num = len(matrix)
    node_left = node_num >> 1
    # 邻接矩阵转化为邻接表，对稀疏图可提高下面循环的效率
    graph = [{i for i in range(node_num) if matrix[j][i] == 1} for j in range(node_num)]
    checked = [-1] * node_num  # 记录某节点i是否已在checked[i]节点为根的先宽搜索树中
    prev = [-1] * node_num     # 记录交替路径中某右部节点的上一个右部节点，左部节点已被matched记录
    matched = [-1] * node_num  # 记录某节点匹配的节点
    for i in range(node_left, node_num):
        if matched[i] != -1:   # i应是某尚未匹配的右部节点
            continue
        # 先宽搜索队列只记录右部节点，这些节点是左部节点通过已有匹配边一一对应来的
        bfs_queue = [i]
        pos = 0                # 记录遍历队列的当前位置
        flag = False           # 一次搜索找到一条增广路径即完成
        prev[i] = -1           # i记录为路径起点
        while pos < len(bfs_queue) and not flag:
            node = bfs_queue[pos]
            # node是右部节点，j是与之相邻的左部节点
            for j in graph[node]:
                if checked[j] == i:
                    continue
                checked[j] = i
                # 将j匹配的右部节点加入队列继续搜索
                if matched[j] > -1:
                    bfs_queue.append(matched[j])
                    prev[matched[j]] = node
                # j没有匹配的右部节点说明找到增广路径
                else:
                    flag = True
                    t1, t2 = node, j
                    while t1 != -1:
                        t3 = matched[t1]
                        matched[t1] = t2
                        matched[t2] = t1
                        t1 = prev[t1]
                        t2 = t3
                if flag:
                    break
            pos += 1
        # 该右部节点无法匹配说明不存在完美匹配，此时搜索队列即组成一个受限组。
        # 因为i未能匹配说明前面没有从i出发找到增广路径，即i的搜索树中左部节点总是通过已有匹配一一对应到其他右部节点，
        # 因此这些右部节点和i恰比它们的邻居左部节点多1
        if matched[i] == -1:
            return False, {matched[n] for n in bfs_queue if n != i}
    return True, {(i, matched[i]) for i in range(node_left)}
