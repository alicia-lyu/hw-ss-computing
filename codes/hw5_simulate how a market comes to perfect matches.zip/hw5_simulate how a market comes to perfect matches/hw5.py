# hw5 simulate how a market comes to perfect matches https://karenlyu21.github.io/hw-ss-computing/5.html
from perfectMatch import perfect_match 
import numpy as np
import os

def arrayGen(filename): # derive the array from the input file
    f = open(filename, 'r')
    r_list = f.readlines()
    f.close()
    bids = []
    book_list = []
    for line in r_list:
        if line == '\n': # remove blank lines
            continue
        # convert a line to elements within
        line = line.strip('\n')
        line = line.strip()
        if filename.endswith('.txt'):
            row_list = line.split() # txt: split when whitespace is encounteded
        else:              
            row_list = line.split(',') # csv: split when ',' is encounteded
            del row_list[0] # delete the column with the sequence number
            if line in r_list[0]: # the first line of csv file should be removed
                book_list = row_list
                continue
        # integralization
        for k in range(len(row_list)):
            row_list[k] = row_list[k].strip()
            try:
                row_list[k] = int(row_list[k])
            except:
                row_list[k] = float(row_list[k])
        bids.append(row_list)
    # the array of bids
    bids = np.array(bids)
    items = len(bids[0])
    buyers = len(bids)
    return bids, items, buyers, book_list

# input file
for i in range(3):
    try:
        fname = input('请输入出价数据文件名（val2.txt or prices.csv）：')
        pathname = os.path.join('./input',fname)
        bids, items, buyers, book_list = arrayGen(pathname)
    except:
        print('输入错误。', end='')
        fname = None
if fname == None:
    print('使用默认文件val2.txt')
    fname = 'val2.txt'
    pathname = './input/val2.txt'
    bids, items, buyers, book_list = arrayGen(pathname)

print('items: %i, buyers: %i.' % (items, buyers))
print('bids:')
print(bids)
prices = np.zeros(items) # prices set for each item
round = 0
while True:
    round += 1
    print('- - - - - - - - - - - - - - - - - - round %i - - - - - - - - - - - - - - - - - -' % round)
    # market: each person want the item(s) with the max difference between his bid and the set price
    market = np.zeros((items + buyers,items + buyers))
    for i in range(buyers):
        diff_max = bids[i][0] - prices[0]
        bid_item = [0]
        for j in range(1, items):
            # the starting-point of comparison: the first item
            bid = bids[i][j]
            diff = bid - prices[j]
            # compare to get the most wanted item
            if diff > diff_max:
                diff_max = diff
                bid_item = [j]
            elif diff == diff_max:
                bid_item.append(j)
        # the most wanted item(s) is denoted 1
        for k in bid_item:
            market[items + i][k] = 1
            market[k][items + i] = 1

    if perfect_match(market)[0]: # succeed clearing
        print('清仓价格：', end = '')
        print(prices)
        wellBeing = 0
        bought_dict = {}
        for item in perfect_match(market)[1]:
            bought = item[0]
            buyer = item[1] - buyers
            final_bid = bids[buyer][bought]
            final_price = prices[bought]
            final_diff = final_bid - final_price
            bought_dict[buyer] = [bought, final_price, final_diff]
            wellBeing += final_bid
            print('右边买家%i与左边卖家%i匹配，他该支付%i，得最大差价%i。' \
                % (buyer, bought, final_price, final_diff))
        print('优化的社会福利为：', end = '')
        print(wellBeing)
        # output which person need to buy which book specifically
        if fname.endswith('.csv'):
            while True:
                me = input('Which one is you? (input integers from 0 to 10)\nTo know which one Wenhui needs to buy, input 10.\ninput here: ')
                try:
                    me = int(me)
                    if me in range(11):
                        break
                except:
                    pass
                print('Wrong input.', end = ' ')
            bookBought = book_list[bought_dict[me][0]]
            print('I need to buy %s at the cost of %i, getting the largest difference of %i.' \
                % (bookBought, bought_dict[me][1], bought_dict[me][2]))
        break
    
    # Clearance not met
    print('未能清仓。Prices for the next round:', end = ' ')
    # raise the neighbor(s)'s price(s) to 1 point higher
    nb_set = perfect_match(market)[1]
    for i in nb_set:
        prices[i] += 1 
    print(prices)
