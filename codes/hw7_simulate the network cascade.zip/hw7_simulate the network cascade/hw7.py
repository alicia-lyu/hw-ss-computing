# hw7 simulate the network cascade https://karenlyu21.github.io/hw-ss-computing/7.html
import numpy as np

# open the file and get the matrix of the network
def arrayGen(filename):
    f = open(filename, 'r')
    r_list = f.readlines()
    f.close()
    array_nl = []
    for line in r_list:
        if line == '\n':
            continue
        line = line.strip('\n')
        line = line.strip()
        row_list = line.split()
        for k in range(len(row_list)):
            row_list[k] = row_list[k].strip()
            row_list[k] = int(row_list[k])
        array_nl.append(row_list)
    n = len(array_nl[0])
    array = np.array(array_nl)
    return array, n

while True:
    filename = input('请输入矩阵名称（net1.dat / net2.dat / net3/dat）：')
    try:
        A, n = arrayGen(filename)
    except:
        print('输入错误！', end = '')
        continue
    break

# input the starting points
while True:
    S_input = input('请输入初用集（0–%i之间的自然数，用半角逗号分开）：' % (n-1))
    try:
        S_input = S_input.strip()
        S_list_str = S_input.split(',')
        S_list = []
        for S in S_list_str:
            S = S.strip()
            S = int(S)
            S_list.append(S)
    except:
        print('输入格式不正确。', end = '')
        continue
    break

users = S_list

# input the threshold value
while True:
    q = input('请输入门槛值（0–1之间的小数）：')
    try:
        q = float(q)
    except:
        print('输入格式不正确。', end = '')
        continue
    break

# write who's whose friend in a dictionary
friends_all = {}
for i in range(n):
    friends_ind = []
    for j in range(n):
        edge = A[i][j]
        if edge == 1:
            friends_ind.append(j)
    friends_all[i] = friends_ind

# cascade
rnd = 0
print('一开始的新用户：', end = '')
print(users)
while True:
    rnd += 1
    new_users = []
    for i in range(n):
        if i in users:
            continue # inspect each individual, see whether he or she wants to switch to the new app
        friends_ind = friends_all[i] # all friends
        friends_users = [j for j in friends_ind if j in users] # friends who are using the new app
        influence = len(friends_users) / len(friends_ind) # the portion of friends who are using the new app
        if influence >= q: # willing to switch
            new_users.append(i)
    users += new_users
    if new_users == []:
        print('级联结束。')
        break
    print('第%i轮的新用户：' % rnd, end = '')
    print(new_users)
