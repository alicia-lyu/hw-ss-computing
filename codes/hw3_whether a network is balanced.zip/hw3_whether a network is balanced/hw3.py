# hw3 determine whether a network is balanced https://karenlyu21.github.io/hw-ss-computing/3.html
import numpy as np
import sys
import os

# generate an array from a file
def arrayGen(filename):
    f = open(filename, 'r')
    r_list = f.readlines()
    f.close()
    array_nl = []
    for line in r_list:
        if line == '\n':
            continue
        line = line.strip('\n')
        line = line.strip()
        row_list = line.split(',')
        for k in range(len(row_list)):
            row_list[k] = row_list[k].strip()
            row_list[k] = int(row_list[k])
        array_nl.append(row_list)
    n = len(array_nl[0])
    print('输入矩阵路径：%s' % filename)
    array = np.array(array_nl)
    return array, n

# use recursion to designate a group, in which all nodes have an edge of "1" inbetween
def cluster(array, i, group):
    group.append(i)
    for j in range(len(array[i])):
        if j not in group:
            if array[i][j] == 1:
                cluster(array, j, group) # recursion, start from second-order nodes
    return group

try:
    filename = input('请输入文件名（default: balance1.txt）：')
    pathname = os.path.join('./input',filename)
    array, n = arrayGen(pathname)
except:
    print('输入错误，采用默认文件balance1.txt')
    pathname = './input/balance1.txt'
    array, n = arrayGen(pathname)
print(array)


# groups, in which all nodes have an edge of "1" inbetween
groups = []
cnt = 0
start = 0
rest = [i for i in range(n)]
while True:
    groups.append([])
    groups[cnt] = cluster(array, start, groups[cnt])
    for j in groups[cnt]:
        rest.remove(j)
    if rest == []:
        break
    start = rest[0]
    cnt += 1
print('连通分量如下：')
print(groups)

## whether there's an edge of "-1" inside a group
innerGroup = False
for group in groups:
    for a in range(len(group)):
        node1_1 = group[a]
        if innerGroup == False:
            for node1_2 in group[a+1:]:
                if array[node1_1][node1_2] == -1: 
                # if True, two nodes inside a group have an edge of "-1", violating the equilibrium theorem
                    innerGroup = True
                    break
if innerGroup == True:
    print('★★连通分量内部有负边，该网络不平衡。★★')
    print('★★★★该网络不是平衡网络。★★★★')
    sys.exit(0)

# sketchy network consisting of previously generated groups
array2 = np.zeros((cnt+1,cnt+1))
## whether groups have edges inbetween
for i in range(len(groups)):
    group = groups[i]
    for j in range(i+1, len(groups)):        
        next = groups[j]
        edgeExist = False
        for node1 in group:
            if edgeExist == True:
                break     
            for node2 in next:
                if array[node1][node2] == -1: # if true, two groups have an edge of "-1" inbetween
                    array2[i][j] = 1 # here all edges are -1, just designate them as 1 for the purpose of simplification
                    array2[j][i] = 1
                    edgeExist = True
                    break
print('简约网络图如下：')
print(array2)


# converting the sketchy network to a structure of layers

## Breadth-First Search
layers = []
layerCon = []
counted = [0]
def bfs(i_list, layerNum, array = array2):
    global layers
    global layerCon
    global counted
    layers.append([])
    layerCon.append([])
    j_list = []
    for i in i_list:
        layers[layerNum].append(i)
        if len(counted) == len(array):
            break
        for j in range(len(array[i])):
            if j not in counted:
                if array[i][j] == 1:
                    layerCon[layerNum].append([i, j])
                    j_list.append(j)
    j_set = set(j_list)
    j_list = list(j_set)
    for j in j_list:
        counted.append(j)
    layerNum += 1
    if j_list != []:
        bfs(j_list, layerNum) # recursion, start from the next layer
    return layers, layerCon
    
    

# if there is an internal edge inside a layer, find out the circle consisting of odd numbers of -1 edges
def circleSpotter(i, j, layerI, oddCir, layerCon = layerCon, layers = layers):
    def nodeAdder(edge, x):
        for node in edge:
            if node != i and node in layers[layerI - 1]:
                oddCir.append(node)
                i2 = node
        return oddCir, i2
    i_counted = False
    j_counted = False
    for edge in layerCon[layerI - 1]:
        if i in edge:
            if i_counted == True:
                continue
            oddCir, i2 = nodeAdder(edge, i)
            i_counted = True
        elif j in edge:
            if j_counted == True:
                continue
            oddCir, j2 = nodeAdder(edge, j)
            j_counted == True
    layerI -= 1
    if i2 != j2:
        circleSpotter(i2, j2, layerI, oddCir) # recursion, start from upper layer
    oddCirSet = set(oddCir)
    oddCir = list(oddCirSet) # make sure there aren't duplicates
    return oddCir


oddCirs = []
oddcnt = -1
innerLayer = False
layers, layerCon = bfs([0], 0)
print('layers:')
print(layers)
print('层间边：')
print(layerCon)

for layer in layers:
    layerI = layers.index(layer)
    for x in range(len(layer)):
        i = layer[x]
        for j in layer[x+1:]:
            if array2[i][j] == 1: # if True, [i,j] is an internal edge within a layer
                innerLayer = True 
                oddcnt += 1
                oddCirs.append([i, j])
                oddCir = oddCirs[oddcnt]
                oddCir = circleSpotter(i, j, layerI, oddCir) # find out the circle with odd numbers
                oddCirs[oddcnt] = oddCir

if innerLayer == True:
    print('★★层内有边，该网络不平衡。★★')
    print('构成奇数边数的圆的节点如下：')
    print(oddCirs)
else:
    print('无层内边。')

if innerLayer == False:
    print('★★★★该网络为平衡网络。★★★★')
else:
    print('★★★★该网络不是平衡网络。★★★★')




    

                



