# hw10 calculate the voting results according to Condorcet model https://karenlyu21.github.io/hw-ss-computing/10.html
print('Initiating...')
import numpy as np
import os

# 打开文件读取排序/投票结果
def votes_reader(filename):
    f = open(filename, 'r')
    votes_lines = f.readlines()
    votes = []
    for line in votes_lines:
        line = line.strip()
        votes_individual = line.split()
        votes_indv_new = []
        for vote in votes_individual:
            vote = int(vote)
            votes_indv_new.append(vote)
        votes.append(votes_indv_new)
    votes = np.array(votes)
    return votes
cnt = 0
while True:
    cnt += 1
    if cnt > 3:
        print('使用默认文件b2。')
        votes = votes_reader('./input/b2')
    try:
        filename = input('输入文件名（如b2)：')
        pathname = os.path.join('./input', filename)
        votes = votes_reader(pathname)
    except:
        print('输入错误。', end = '')
        continue
    break

print('投票结果：')
print(votes)
## compare votes on two candidates
def compare(i,j,votes): 
    n = len(votes) # number of voters
    advantage = 0 # accumulative advantage of i over j according to all voters
    i_indices = np.where(votes == i)
    j_indices = np.where(votes == j)
    for k in range(n):
        i_index = i_indices[1][k]
        j_index = j_indices[1][k]
        if i_index < j_index: # i ranks higher than j, according to voter k
            advantage += 1
        else:
            advantage -= 1
    return advantage

# Condorcet ranking (a different algorithm from the one taught in class)
def condorcet(votes):
    n = len(votes) # number of voters
    assert n % 2 == 1 # make sure there are an odd number of voters
    m = len(votes[0]) # number of candidates
    order = [0]
    # bubble sorting
    for i in range(1, m):
        for j_index in range(len(order)):
            flag = False
            j = order[len(order) - j_index - 1]
            advantage = compare(i, j, votes)
            if advantage < 0:
                order.insert(j_index+1, i)
                flag = True
                break # compare the new candidate to existing candidates in the order, from the least favored to the most, 
                      # until we find a more favored existing candidate, so that we can insert the new candidate after it
        if flag == False:
            order.insert(0, i) # All existing candidates are less favored than the new one
    return order

# 检查投票结果是否隐含孔多塞悖论
## the main act: check if there is Condorcet paradox
def condorcet_paradox_check(votes):
    m = len(votes[0])
    n = len(votes)
    
    ## generate a matrix which denotes which of two candidates is more preferred
    def preference_matrix_generator(votes): 
        preference_matrix = np.zeros((m,m))
        assert n % 2 == 1
        for i in range(m-1):
            for j in range(i+1,m):
                advantage = compare(i, j, votes)
                if advantage > 0: # i is more preferred than j
                    preference_matrix[i][j] = 1
                    preference_matrix[j][i] = -1
                else:
                    preference_matrix[i][j] = -1
                    preference_matrix[j][i] = 1
        return preference_matrix
    preference_matrix = preference_matrix_generator(votes)
    print('孔多塞排序有向图（初始）：')
    print(preference_matrix)

    ## delete the nodes whose entry degree is 0
    def most_preferred_deleter(preference_matrix):
        deleter_bool = False # whether there is indeed a node to be deleted
        for i in range(len(preference_matrix)):
            preference_individual = preference_matrix[i]
            flag = True
            for item in preference_individual:
                if item < 0:
                    flag = False
                    break
            if flag == True:
                deleter_bool = True
                preference_matrix = np.delete(preference_matrix, i, 0)
                preference_matrix = np.delete(preference_matrix, i, 1)
                break # There's no possibility that a given matrix has two nodes whose entry degrees are 0 at the same time
        return preference_matrix, deleter_bool

    while True:
        preference_matrix, deleter_bool = most_preferred_deleter(preference_matrix)
        # print(preference_matrix)
        if deleter_bool == False: 
            break # break when there is no node to be deleted
    if len(preference_matrix) == 0:
        paradox_bool = False
        print('不存在孔多塞悖论。')
    else:
        paradox_bool = True
        print('存在孔多塞悖论。')
    return paradox_bool

# 删除违反单峰性质的voters
def irrational_voters_deleter(votes):

    ## check whether values vary monotonically with keys
    def monotonic_check(order_dict, right_or_left): 
        # order_dict -- candidate : order
        monotonic_bool = True
        keys = list(order_dict.keys())
        keys.sort()
        values = list(order_dict.values())
        values.sort()
        for i in range(len(keys)):
            key = keys[i]
            values_len = len(values)
            if right_or_left == 'right': # value = f(key) monotonic rising
                value = values[i]
            elif right_or_left == 'left': # value = f(key) monotonic falling
                value = values[values_len - i - 1]
            else:
                raise Exception('The argument “right_or_left” for function *monotonic_check* need a string variable which is either "right" or "left".')
            if order_dict[key] != value: # actual value != the correspondent value with regard to the monotonic order
                monotonic_bool = False
                break
        return monotonic_bool
    
    ## check whether an indivisual's votes satisfy the single-peak attribute
    def single_peak_check(votes_individual): 
        most_preferred = votes_individual[0]
        rightwing = {} # votes on those candidates whose attributive order is higher than the most preferred one
        leftwing = {} # votes on those candidates whose attributive order is lower than the most preferred one
        for i in range(most_preferred + 1, m):
            i_index = np.where(votes_individual == i)
            rightwing[i] = i_index[0][0]
        for i in range(0, most_preferred):
            i_index = np.where(votes_individual == i)
            leftwing[i] = i_index[0][0]
        # The voter's behavior satisfies single-peak attribute, when both the left wing and the right wing are monotonic
        rightwing_bool = monotonic_check(rightwing, 'right')
        leftwing_bool = monotonic_check(leftwing, 'left')
        return rightwing_bool and leftwing_bool

    m = len(votes[0])
    irrational_voters = []
    for i in range(len(votes)):
        votes_individual = votes[i]
        single_peak_bool = single_peak_check(votes_individual)
        if single_peak_bool == False:
            irrational_voters.append(i)
    print('违反单峰性质的voters序号（初始矩阵行号）：', end = '')
    print(irrational_voters)
    
    ## generate a new matrix which excludes the irrational voters
    n = len(votes)
    cnt = 0
    for i in range(n):
        if i in irrational_voters:
            continue
        if cnt == 0:
            votes_new = votes[i]
            votes_new = np.reshape(votes_new, (-1, m)) # 1d to 2d (in order to concatenate into a 2-d array)
        else:
            votes_appended = votes[i]
            votes_appended = np.reshape(votes_appended, (-1, m))
            votes_new = np.concatenate((votes_new, votes_appended), axis = 0)
        cnt += 1
    
    ## make sure there is an odd number of voters
    if len(votes_new) % 2 == 0:
        print('删除非理性投票者后，总人数不为奇数，补齐一个投票者，其偏好序为属性序。')
        votes_default = np.array([[0,1,2,3,4,5,6,7,8,9]])
        votes_new = np.concatenate((votes_new, votes_default), axis = 0)
    print('删除非理性投票者后的矩阵为：')
    print(votes_new)
    
    return votes_new
      
# 根据中位项定理排序
def median_identifier(votes):
    candidates_num = len(votes[0])
    n = len(votes)
    most_preferred_choices = [] # collect the most preferred choice of all voters
    for votes_individual in votes:
        most_preferred_choices.append(votes_individual[0])
    most_preferred_choices_array = np.array(most_preferred_choices)
    ## identify the choice of the median voter
    unique, counts = np.unique(most_preferred_choices_array, return_counts=True)
    occurences = dict(zip(unique, counts))
    accumulation = 0
    for candidate in occurences.keys(): # add up occurences, starting from the first one in the attributive order
        accumulation += occurences[candidate]
        if accumulation >= (n+1) // 2:
            break # when we break the loop here, i denotes the choice of the median voter
    print(candidate, end = ', ')
    return candidate

paradox_bool = condorcet_paradox_check(votes)
if paradox_bool == False:
    condorcet_order = condorcet(votes)
    print('根据孔多塞定理，全排序如下：', end = '')
    print(condorcet_order)
else:
    votes_new = irrational_voters_deleter(votes)
    rational_voters_num = len(votes_new)
    print('根据中位项定理，全排序如下：', end = '')
    while True:
        median_choice = median_identifier(votes_new)
        if len(votes_new[0]) == 1:
            break
        # exclude the already chosen candidates, so as to repeat the process of identifying the choice of the median voter
        m = len(votes_new[0]) - 1
        votes_new = votes_new[votes_new != median_choice]
        votes_new = np.reshape(votes_new, (rational_voters_num, m))
        
