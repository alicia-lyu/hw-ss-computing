# hw9 investigate the relationship between PageRank and DeGrook consensus https://karenlyu21.github.io/hw-ss-computing/9.html
print('Initiating...')
import numpy as np
import os

# 从文件中读取矩阵
def arrayGen(filename):
    f = open(filename, 'r')
    r_list = f.readlines()
    f.close()
    array_nl = []
    for line in r_list:
        if line == '\n':
            continue
        line = line.strip('\n')
        line = line.strip()
        row_list = line.split()
        for k in range(len(row_list)):
            row_list[k] = row_list[k].strip()
            row_list[k] = int(row_list[k])
        array_nl.append(row_list)
    nx = len(array_nl[0])
    ny = len(array_nl)
    array = np.array(array_nl)
    return array, nx, ny

## 请求输入文件名称
while True:
    filename = input('请输入有向图邻接矩阵文件名称（e.g. net1.dat, net2.dat）：')
    pathname = os.path.join('./input',filename)
    try:
        A, nx, ny = arrayGen(pathname)
    except:
        print('输入错误！', end = '')
        continue
    break
print('有向图：')
print(A)
# 从文件中读取向量
def vecGen(filename):
    f = open(filename, 'r')
    value_list = f.readlines()
    f.close()
    for i in range(len(value_list)):
        value = value_list[i]
        value = value.strip()
        value = int(value)
        value_list[i] = value
    value_array = np.array(value_list)
    return value_array, len(value_array)
    
## 请求输入文件名称
while True:
    filename = input('请输入认识初值向量文件名称（e.g. s1.dat, s2.dat）：')
    pathname = os.path.join('./input',filename)
    try:
        S, n = vecGen(pathname)
    except:
        print('输入错误！', end = '')
        continue
    break
print('初始观点向量：',end='')
print(S)
# 标准化矩阵
A_sd = np.zeros((ny,nx))
for i in range(ny):
    row = A[i]
    recognition_sum = np.sum(row)
    A_sd[i] = row / recognition_sum

# DeGroot
## 变换横纵轴
A_trans = np.transpose(A_sd)
S_initial = np.copy(S)
# print('S_initial:')
# print(S_initial)
cnt = 0
while True:
    cnt += 1
    S_original = np.copy(S)
    S = np.dot(S, A_trans)
    # if cnt == 1:
    #     print(A_trans, end ='')
    #     print(' * ', end ='')
    #     print(S_original, end = '')
    #     print('= ', end = '')
    #     print(S)
    ## 检验是否达成稳定
    flag = True
    for i in range(n):
        s_original = '%.3f' % S_original[i]
        s = '%.3f' % S[i]
        if s_original != s:
            flag = False
    if flag == True:
        break
S_output = ['%.3f' % s for s in S]
print('*** DeGroot 共识结果：')
print(np.array(S_output))

# PageRank
V = np.array([1/n for i in range(n)])
cnt = 0
while True:
    cnt += 1
    V_original = np.copy(V)
    V = np.dot(V, A_sd)
    # if cnt == 1:
    #     print(A_sd, end ='')
    #     print(' * ', end ='')
    #     print(V_original, end = '')
    #     print('= ', end = '')
    #     print(V)
    ## 检验是否达成稳定
    flag = True
    for i in range(n):
        v_original = '%.5f' % V_original[i]
        v = '%.5f' % V[i]
        if v_original != v:
            flag = False
    if flag == True:
        break
print('*** PageRank: ')
V_output = ['%.3f' % v for v in V]
print(np.array(V_output))
# 使用PageRank对初始观点加权求和
consensus = np.dot(V,S_initial)
print('*** PageRank 加权初值求和结果：%.3f' % consensus)