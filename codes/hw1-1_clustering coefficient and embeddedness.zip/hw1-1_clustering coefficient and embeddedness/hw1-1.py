# hw1-1 calculate clustering coefficient and embeddedness https://karenlyu21.github.io/hw-ss-computing/1.html
import numpy as np
# read data file and store the matrix in the form of a nested list
def arrayGen(filename):
    f = open(filename, 'r')
    r_list = f.readlines()
    f.close()
    A = []
    for line in r_list:
        if line == '\n':
            continue
        line = line.strip('\n')
        line = line.strip()
        row_list = line.split()
        for k in range(len(row_list)):
            row_list[k] = row_list[k].strip()
            row_list[k] = int(row_list[k])
        A.append(row_list)
    n = len(A[0])
    print('输入矩阵路径：%s' % filename)
    A = np.array(A)
    return A, n

try:
    filename = input('请输入邻接矩阵文件名（如net3.txt）：')
    A, n = arrayGen('./input/%s' % filename)
except:
    print('输入错误，使用默认文件net3.txt。')
    A, n = arrayGen('./input/net3.txt')

# my method here doesn't exploit matrix multiplying, because, according to formation of the question, matrices involved here are binary. 
# Therefore, a more efficient way which avoids multiplication is taken up here.

# clustering coefficient
## store who's whose friend in a dictionary
friend_dict = {}
for i in range(n):
    friend_dict[i] = []
    for j in range(n):
        if A[i][j] == 1:
            friend_dict[i].append(j)
## count tridiac closures
ClCo_dict = {}
for (person, friend_list) in friend_dict.items():
    TriCl = 0
    for x in range(len(friend_list)):
        friend1 = friend_list[x]
        for y in range(x+1, len(friend_list)):
            friend2 = friend_list[y]
            if A[friend1][friend2] == 1:
                TriCl += 1
## calculate clustering coefficient
    PossTriCl = len(friend_list) * (len(friend_list) - 1) / 2
    if PossTriCl == 0:
        ClCo = 0
    else:
        ClCo = TriCl / PossTriCl
    ClCo_dict[person] = ClCo

# output clustering coefficient
print()
print('clustering coefficient as following:')
ClCo_list = list(ClCo_dict.items())
ClCo_list.sort(key = lambda x:x[1], reverse = True)
if len(ClCo_dict) < 10:
    for item in ClCo_list:
        print('node', str(item[0]) + ':', '%.2f' % item[1])
else:
    for item in ClCo_list[0:10]:
        print('node', str(item[0]) + ':', '%.2f' % item[1])

# calculate embeddedness
embd_dict = {}
for (person, friend_list) in friend_dict.items():
    for friend_a in friend_list:
        if friend_a > person:
            embd_dict[person, friend_a] = 0
            for friend_b in friend_dict[friend_a]:
                if friend_b in friend_list:
                    embd_dict[person, friend_a] += 1

# output embeddedness
print()
print('embeddedness as following:')
embd_list = list(embd_dict.items())
embd_list.sort(key = lambda x:x[1], reverse = True)
if len(embd_list) < 10:
    for item in embd_list:
        print('edge', end = ' ')
        print(item[0], end = '')
        print(':', str(item[1]))
else:
    for item in embd_list[0:10]:
        print('edge', end = ' ')
        print(item[0], end = '')
        print(':', str(item[1]))